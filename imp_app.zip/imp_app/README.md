# IMP – click-through front end

Flutter version of Wireframes v1.3. Front end only: fake data, no backend, any login works.

## Run it

```bash
cd imp_app
flutter create . --project-name imp_app   # adds the android/ios/web/windows/macos folders (keeps lib/ as is)
flutter pub get
flutter run                               # or: flutter run -d chrome
```

Best viewed at tablet size (portrait). On a phone-width window the sidebar moves into a drawer.

## How to click through

| Wireframe | How to get there |
|---|---|
| 01a Tablet setup | App start. Any email/password, or either "Continue with…" button |
| 02a Employee sign-in | After setup, or **Switch user**. Pick a name, tap any 6 digits |
| 03a Dashboard | After sign-in. Tap a tile → Boxes for that category |
| 03b/03c Master mode popups | Tap the **Master off/on** tag above the name, or any locked Master-only item |
| 01b Master sign-in | "Turn on" in the Master popup. Any login works |
| 04 Boxes | Sidebar, a dashboard tile, or **Search** in the bottom bar. Search/filters work on the fake data |
| 05a/b/c Scanner | **Scan** in the bottom bar. Tap the viewfinder or a demo button (no camera yet) |
| 06a–e Box page | Tap any box. Change a field → Save lights up; Back with unsaved changes asks to save; Unrack / Re-rack; Delete box |
| 07 New box | **+** on Boxes |
| 08a/b Categories | Sidebar. **+** or **Edit** opens the popup |
| 09 Alerts | **Alerts** in the bottom bar |
| 10a/b Accounts | Master mode. **+** / Edit / Deactivate |
| 11a/b/c Buildings | Master mode. Remove "Old Annex" → blocked; remove "Back Garage" → confirm |
| 12 Devices | Master mode. View only |
| 13a/b Deleted Items | Master mode. Restore / Delete permanently |
| 14 Audit Log | Master mode. Tap a row to expand it |

Actions that would need the backend (save, delete, add, print) just close the popup and show a short "demo only" message.

## Where things are

```
lib/
  main.dart               app entry, starts on tablet setup
  theme.dart              grayscale colors from the wireframe style
  app_state.dart          current user + Master mode flag (replace with real auth)
  data/mock_data.dart     all sample data from the wireframes (replace with API calls)
  widgets/app_shell.dart  sidebar, bottom bar, page header, Master mode flow
  widgets/common.dart     buttons, segmented control, tags, cards, popups
  widgets/box_row.dart    box list row
  screens/                one file per wireframe screen
```

No packages beyond Flutter itself. The QR code on the box page is a fake pattern; the scanner has no camera yet.
